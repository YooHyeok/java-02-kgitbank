package Car_Info;

public class Car_Main {

	public static void main(String[] args) {

		Car car3 = new Car();
		
		Car car1 = new Car("Car1","red","Manual",2);

		Car car2 = new Car("Car2","blue","auto",4);
		
//		System.out.println("[Car1의 정보]");
//		System.out.println("color : " + car1.color);
//		System.out.println("gearType : " + car1.gearType);
//		System.out.println("door : " + car1.door);
//		
//		System.out.println("[Car2의 정보]");
//		System.out.println("color : " + car2.color);
//		System.out.println("gearType : " + car2.gearType);
//		System.out.println("door : " + car2.door);

	}

}
