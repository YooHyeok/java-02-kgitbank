
public class ClassEx {

	public static void main(String[] args) {
		
	}

}
