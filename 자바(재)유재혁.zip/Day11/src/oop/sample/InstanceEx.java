package oop.sample;//oop라는 대분류 안에 sample이라는 소분류 패키지에서 불러옴 - 접근지정자

public class InstanceEx { //클래스 이름

	public static void main(String[] args) {

	}

}

class Info{
	int age;
}
