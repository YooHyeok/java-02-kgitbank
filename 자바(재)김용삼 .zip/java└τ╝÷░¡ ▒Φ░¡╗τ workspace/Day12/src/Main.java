import java.util.Scanner;

import oop.sample.*;


public class Main {

	public static void main(String[] args) {
//		String name = "ȫ�浿";
//		int age = 28;
//		
//		System.out.println("�̸� : " + name);
//		System.out.println("���� : " + age);
		
//		Info inf = new Info();
//		System.out.println("Before age = " + inf.age);
//		inf.age = 35;
//		System.out.println("After age = " + inf.age);

//		inf.setInfo("�谭��",  35);
//		inf.disp();	
//		
//		String color;
//		Scanner sc = new Scanner(System.in);
//		color = "red";
		Tv t  = new Tv();
		
		t.power();
		t.showChannel();
		t.setChannel(32);
		for(int i=0; i<5; i++) {
			t.channelUp();
		}

		for(int i=0; i<39; i++) {
			t.channelDown();
		}
		
		t.setChannel(32);
		
		t.power();

	}
}



















