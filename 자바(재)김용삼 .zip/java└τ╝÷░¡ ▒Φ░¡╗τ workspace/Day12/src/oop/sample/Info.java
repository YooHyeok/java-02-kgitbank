package oop.sample;

public class Info {
	String name = "ȫ�浿";
	int age = 20;
	
	public void setInfo(String name, int age) {
		if(age>40 || age<=0) {
			return;
		}
		this.name = name;
		this.age = age;
	}
	
	public void disp() {
		System.out.println("�̸� : " + name);
		System.out.println("���� : " + age);
	}
			
}
