package oop.lab;

public class MethodTest {
	public int methodTest;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}
	

}
