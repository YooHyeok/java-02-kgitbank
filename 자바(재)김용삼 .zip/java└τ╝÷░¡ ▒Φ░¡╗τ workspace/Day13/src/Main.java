
public class Main {

	public static void main(String[] args) {
		//int add(int a, int b){
		//	int result = a+b;
		//	return result;		
		//}
		//�޼��� ȣ��
		//	- ��������.�޼����̸�();
		//	- ��������.�޼����̸�(��1, ��2, ...);
//		Main res = new Main();
//		
//		int result;
//		result = res.add(3, 10);
//		System.out.println("result(3, 10)="+result);
//		
//		int[] result1 = {0, 0};
//		res.addArray(3, 10, result1);
//		System.out.println("result1[0]=" + result1[0]);
//		System.out.println("result1[1]=" + result1[1]);
		
		//static�޼���� ���� Ŭ���� ���� �ν��Ͻ� �޼��带 ȣ���� �� ����.
		
		MethodEx me = new MethodEx();
		long result;
		result = me.add(5L, 3L);
		System.out.println("add(5L,3L)=" + result);

		result = me.subtract(5L, 3L);
		System.out.println("add(5L,3L)=" + result);
		
		result = me.multiply(5L, 3L);
		System.out.println("add(5L,3L)=" + result);
		
		System.out.println("add(5L,3L)=" + me.divide(5L,  3L));
		
		//============================static method call
		System.out.println("static add=" + MethodEx.sAdd(200L, 100L));
		System.out.println("static sub=" + MethodEx.sSubtract(200L, 100L));
		System.out.println("static mul=" + MethodEx.sMultiply(200L, 100L));
		System.out.println("static div=" + MethodEx.sDivide(200L, 100L));

		System.out.println("���������� �̿��� ����");
		System.out.println("static add=" + me.sAdd(200L, 100L));
		System.out.println("static sub=" + me.sSubtract(200L, 100L));
		System.out.println("static mul=" + me.sMultiply(200L, 100L));
		System.out.println("static div=" + me.sDivide(200L, 100L));
	}
	
	int add(int a, int b) {
		int result = a+b;
		
		return result;
		//return a+b;
	}
	
	void addArray(int a, int b, int[] result) {
		result[0] = a+b;
		//���� Ŭ������ �޼��峢���� ���� ������ ������� �ʴ´�.
		result[1] = add(3,10) + 10;//1*data size
//		result[1] = result[0] + 10;//1*data size
	}

}

class MethodEx{
	long add(long a, long b){
		long res = a+b;
		return res;
	}

	long subtract(long a, long b){
		long res = a-b;
		return res;
	}
	
	long multiply(long a, long b){
		long res = a*b;
		return res;
	}
	
	double divide(long a, long b){
		double res = (double)a/b;
		return res;
	}
//----------------------------------------
	//static method example
	static long sAdd(long a, long b){
		long res = a+b;
		return res;
	}
	
	static long sSubtract(long a, long b){
		long res = a-b;
		return res;
	}
	
	static long sMultiply(long a, long b){
		long res = a*b;
		return res;
	}
	
	static double sDivide(long a, long b){
		double res = (double)a/b;
		return res;
	}

}


















