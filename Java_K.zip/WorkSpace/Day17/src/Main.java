import java.io.ObjectInputStream.GetField;
import java.util.Locale;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
//		FinalEx fe = new FinalEx();
//		CFinalEx cfe = new CFinalEx();
		
//		fe.setScale(100);
//		fe.getScale();
//		fe.disp();
//		cfe.setScale(100);
//		cfe.getScale();
//		cfe.disp();
		
//		AreaEx ae = new AreaEx();
//		ae.setHeight(30);
//		ae.setArea(ae.getWIDTH(), ae.getHeight());
//		ae.disp();
		
//		Scanner sc = new Scanner(System.in);
//		SkillKey sk = new SkillKey();
//		
//		System.out.print("Ű �Է� : ");
//		String key = sc.next();
//		
//		switch(key.toLowerCase()) {
//		case SkillKey.SKILL1 :
//			System.out.println("SKILL 1");
//			break;
//		case SkillKey.SKILL2 :
//			System.out.println("SKILL 2");
//			break;
//		case SkillKey.SKILL3 :
//			System.out.println("SKILL 3");
//			break;
//		case SkillKey.SKILL4 :
//			System.out.println("SKILL 4");
//			break;
//		default :
//			System.out.println("�߸� �Է�");
//		}
//		AbsEx ae = new AbsEx();
//		CAbsEx2 ae2 = new CAbsEx2();
//		ae.setArea();
//		System.out.println(ae.getArea());
//		CIterfaceEx cife = new CIterfaceEx();
//		cife.setArea(10,  30);
//		System.out.println(cife.getArea());
		
		Outter ot = new Outter();
		ot.i.method();

	}
}

class Outter{
	Inner i = new Inner();	
	class Inner{
		void method() {
			System.out.println("class Inner");
		}
	}
	static class StaticInner{

	}
	void method() {
		class LocalInner{
			int x;
			LocalInner(){}
		}
	}
}

interface InterfaceEx{
	public final static int whidth = 10;
	int height=10;
	
	public abstract void setArea(int width, int height);
	int  getArea();
}
interface InterfaceEx1{
	public final static int whidth = 10;
	int height=10;
	
	public abstract void setArea(int width, int height);
	int  getArea();
}

class CIterfaceEx implements InterfaceEx, InterfaceEx1{
	int area;
	
	public void setArea(int width, int height) {
		area = width * height;
	}
	public int getArea(){
		return area;
	}
}

abstract class AbsEx{
	int width;
	int height;
	int area;
	AbsEx(){
		width =  10;
		height = 30;
	}
	
	abstract void setArea();
	
	int getArea() {
		return area;
	}
}

class CAbsEx extends AbsEx{
	void setArea() {
		width = 20; 
		height = 30;
		area = width * height;
	}
}

class CAbsEx2 extends AbsEx{
	void setArea() {
		
	}
}


class SkillKey{
	final static String SKILL1 = "q";
	final static String SKILL2 = "w";
	final static String SKILL3 = "e";
	final static String SKILL4 = "r";
}
//���� ���ϱ�
//area = width * height;
class AreaEx{
	final private int WIDTH;
	private int height;
	private int area;
	
	AreaEx(){
		WIDTH = 10;
	}
	AreaEx(int width, int height){
		this.WIDTH = width;
		this.height = height;
	}
	
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public int getArea() {
		return area;
	}
	final public void setArea(int width, int height) {
		this.area = width * height;
	}
	public int getWIDTH() {
		return WIDTH;
	}
	
	public void disp() {
		System.out.println("���� : "+getWIDTH());	
		System.out.println("���� : "+getHeight());
		System.out.println("���� : "+getArea());
	}
	
	
}


final class FinalEx{
	final int defaultScale = 100000;
	int scale;
	
	final void setScale(int scale) {
		int level = 1;
//		defaultScale = defaultScale / (scale*level);
		this.scale = defaultScale / (scale*level);;
	}
	
	int getScale() {
		return scale;
	}
	
	void disp() {
		System.out.println("Scale : "+getScale());
	}
	
}

//class CFinalEx extends FinalEx{
//	void setScale(int scale) {
//		this.scale = defaultScale / (scale*scale);
//	}
//}












