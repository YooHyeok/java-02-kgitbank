
public class Main {

	public static void main(String[] args) {
//		Data1 d1 = new Data1();
//		Data2 d2 = new Data2(100);
//		Data2 d3 = new Data2();

//		d2.method();
//		d3.method();		
//		System.out.println("d1.value="+ d1.value);
//		System.out.println("d2.value="+ d2.value);
//		System.out.println("d3.value="+ d3.value);
		
//		Info in = new Info("�谭��", 28);
//		in.dispInfo();
//		Info in1 = new Info("�谭��", 29);
//		in1.dispInfo();
//		
//		in1.setName("�谭��");
//		in1.dispInfo();
		
//		Car car1 = new Car("������", "manual", 2);
//		Car car2 = new Car("�Ķ���", "auto", 4);
//		
//		System.out.println("[car1�� ����]");
//		car1.dispInfo();
//		
//		System.out.println("[car2�� ����]");
//		car2.dispInfo();
//		
//		System.out.println();
//		car2.setColor("�����");
//		car2.setGearType("manual");
//		car2.setDoor(2);
//		System.out.println("[car2�� ����]");
//		car2.dispInfo();
		
//		Player [] user = new Player[3];
//		for(int i=0; i<user.length; i++) {
//			user[i]= new Player();
//		}
//		
//		user[0].setId("����");
//		user[1].setId("������");
//		user[2].setId("���γ�");
//		
//		user[0].levelUp(3);
//		
//		System.out.println("��ȣ\t���̵�\t����\t���ݷ�\t����");
//		for(int i=0; i<user.length; i++) {
//			user[i].disp(i+1);
//		}
		
		Mobile m1 = new Mobile("G6", "LGT", 70);
		Mobile m2 = new Mobile("������7", "KT", 85);
		Mobile m3 = new Mobile("Note10", "SKT", 95);
		
		m1.disp();
		m2.disp();
		m3.disp();
		
		Mobile [] arr = new Mobile[] {m1, m2, m3};
		System.out.println("\tname\ttelecom\tprice");
		for(int i=0; i<arr.length; i++) {
			arr[i].disp(i);
		} 		
	}
}



//����Ʈ�� ��ü�� ���� ���
//		name	telecom	price
//[1]	G6		LG		70����
//[2]	������7	KT		85����
//[3]	Note10	SKT		95����

class Mobile{
	private String name;
	private String telecom;
	private int price;
	
	public Mobile() {}
	public Mobile(String name) {
		this.name = name;
	}
	public Mobile(String name, String telecom, int price) {
		this.name = name;
		this.telecom = telecom;
		this.price =  price;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTelecom() {
		return telecom;
	}
	public void setTelecom(String telecom) {
		this.telecom = telecom;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	public void setData(String name, String telecom, int price) {
		this.name = name;
		this.telecom = telecom;
		this.price = price;
	}
	
	public void disp() {
		System.out.println("�̸� : "+this.name);
		System.out.println("��Ż� : "+this.telecom);
		System.out.println("���� : "+this.price);
	}
	
	public void disp(int num) {
		System.out.print("["+num+"]\t"+name+"\t");
		System.out.println(telecom+"\t"+price+"����");
	}
	
}

//ĳ���� ������ ������ 1, ���ݷ� 5, ü�� 20
//������ ������ ��� ���ݷ��� 3, ü���� 10����
//��ȣ	���̵�	����	���ݷ�	ü��
//[1]	����		3	11		40
//[2]	������	1	5		20
//[3]	���γ�	1	5		20

class Player{
	private String id="";
	private int level;
	private int attack;
	private int hp;
	
	Player(){
		this.level = 1;
		this.attack = 5;
		this.hp = 20;
	}
	
	void setUser(String id, int level, int attack, int hp) {
		this.id = id;
		this.level = level;
		this.attack = attack;
		this.hp = hp;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public int getAttack() {
		return attack;
	}

	public void setAttack(int attack) {
		this.attack = attack;
	}

	public int getHp() {
		return hp;
	}

	public void setHp(int hp) {
		this.hp = hp;
	}
	
	public void levelUp(int level) {
		this.level += level;
		this.attack += level*3;
		this.hp += level*10;
	}
	
	public void disp() {
		System.out.println("ID : "+getId());
		System.out.println("Level : "+getLevel());
		System.out.println("Attack : "+getAttack());
		System.out.println("Hp : "+getHp());
	}
	
	public void disp(int num) {
		System.out.print("["+num+"]");
		System.out.print("\t"+getId());
		System.out.print("\t"+getLevel());
		System.out.print("\t"+getAttack());
		System.out.println("\t"+getHp());
		
	}
}

//�ڵ��� ��ü ����
//[car1�� ����]
//color : ������
//gearType : manual
//door : 2

//[car2�� ����]
//color : �Ķ���
//gearType : Auto
//door : 4
class Car{
	private String color;
	private String gearType;
	private int door;
	
	Car(String color, String gearType, int door){
		this.color = color;
		this.gearType = gearType;
		this.door = door;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getGearType() {
		return gearType;
	}

	public void setGearType(String gearType) {
		this.gearType = gearType;
	}

	public int getDoor() {
		return door;
	}

	public void setDoor(int door) {
		this.door = door;
	}
	
	public void dispInfo() {
		System.out.println("color : "+this.color);
		System.out.println("gearType : "+this.gearType);
		System.out.println("door : "+this.door);
	}
	
	
}


class Info{
	private String name;
	private int age;
	
	Info(){
		this.name = "�谭��";
		this.age =  28;
	}
	
	Info(String name, int age){
		this.name = name;
		this.age =age;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return this.name;
	}
	
	public void setAge(int age) {
		this.age = age;
	}
	public int getAge() {
		return this.age;
	}
	public void dispInfo() {
		System.out.println("�̸� : "+this.name);
		System.out.println("���� : "+this.age);
	}
}
class Data1{
	int value;
}

class Data2{
	int value;
	int temp;

	Data2(){
		this(1000);
		value = 10;
	}
	
	Data2(int x){
		value =  x;
	}
	
	void method() {
		int a, b;
		a=10;
		b=20;
		value = a+b;		
	}
	
}

















