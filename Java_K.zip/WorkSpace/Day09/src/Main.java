import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws InterruptedException {
//		int [] arr = new int[5];
//		
//		for(int i=0; i<arr.length; i++) {
//			arr[i] = i+1;
//		}
//		
//		for(int i=0; i<arr.length; i++) {
//			System.out.println("arr[" +i+ "]=" + arr[i]);
//		}
//		
//		arr[0] += 10; // arr[0] = arr[0] + 10;
//		arr[1] += 20;
//		arr[2] += 30;
//		
//		for(int i=0; i<arr.length; i++) {
//			System.out.println("arr[" +i+ "]=" + arr[i]);
//		}
		
//		int [] card = new int[52];
//		
//		for(int i=0; i<card.length; i++) {
//			card[i] = i+1;
//		}
//		
//		int temp;
//		int indexNum;
//		
//		for(int i=0; i<100; i++) {
//			indexNum = (int)(Math.random()*52);
//			temp = card[0];
//			card[0] = card[indexNum];
//			card[indexNum] = temp;
//		}
//		
//		for(int i=0; i<7; i++) {
//			System.out.print(card[i] + " ");
//		}		
//		System.out.println();
		
		
		//Q1. �ֻ����� 10�� ���� ����� ¦�� Ȧ�� �����Ͽ� ���
//		int [] die = new int[10];
//		
//		for(int i=0; i<die.length; i++) {
//			die[i] = (int)(Math.random()*6)+1;
//			System.out.println((i+1)+"��° : "+ die[i]);
//		}
//		
//		System.out.print("¦�� �ֻ��� : ");
//		for(int i=0; i<die.length; i++) {
//			if(die[i]%2 == 0) {
//				System.out.print(die[i] + " ");
//			}
//		}
//		System.out.print("\nȦ�� �ֻ��� : ");
//		for(int i=0; i<die.length; i++) {
//			if(die[i]%2 != 0) {
//				System.out.print(die[i] + " ");
//			}
//		}
//		System.out.println();
		
		//Q2. �ֻ����� 1000�� ������ ������ ������ ���� Ƚ�� �����
//		int [] dice = new int[6];
//		
//		for(int i=0; i<1000; i++) {
//			int num = (int)(Math.random()*6);
//			dice[num]++;
//		}
//		
//		for(int i=0; i<dice.length; i++) {
//			System.out.println( (i+1)+" ���� Ƚ�� : " + dice[i]);
//		}
		
		//�޴� ���� ���α׷�
		Scanner sc = new Scanner(System.in);
		
		System.out.print("�׸�� �Է� : ");
		int mCount = sc.nextInt();
		
		String [] menu = new String[mCount];
		System.out.println("[ �޴� �Է� ]");
		
		sc.nextLine();
		for(int i=0; i<menu.length; i++) {
			System.out.print((i+1)+"�׸� : ");
			menu[i] = sc.nextLine();
		}
		System.out.println("��÷ �� �Դϴ�.");
		for(int i=0; i<4; i++) {
			System.out.print(".");
			Thread.sleep(500);
		}
		int mSelect = (int)(Math.random()*menu.length);
		
		System.out.println("\n��÷�� �׸��� ["+menu[mSelect]+"] �Դϴ�.");
	}

}














