import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;

public class Main {
	int a;
	public static void main(String[] args) throws IOException {
//		int i = 10;
//		float f = 10.1f;
//		char c = 'A';
//		String str = "Hello World";
//		
//		System.out.println(i);
//		System.out.println(f);
//		System.out.println(c);
//		System.out.print(str);
//		System.out.print("\nHello\tJava|\n");	
//		System.out.printf("%-10d ", i);
//		System.out.printf("%-10.0f ", f);
//		System.out.printf("%-10c\n", c);
//		System.out.printf("%s\n", str);
//		System.out.printf("%s\n", "Hello Java");
		
//		int i = 10;
//		int [] arr = new int[5];
//		
//		System.out.print("�Է� : ");
//		i = System.in.read();
//		System.out.print("��� : ");
//		System.out.println((char)i);
//		arr[0] = i;
//		for(int j=1; j<10; j++) {
//			System.out.print("�Է� " +j+ ": ");
//			i= System.in.read();
//			arr[j] = i;
//			System.out.print("��� " +j+ ": ");
//			System.out.print((char)i);
//			System.out.print(arr[j]+" ");
//		}
		
//		Scanner str = new Scanner(System.in);
//		System.out.print("���� �Է� : ");
//		int age = str.nextInt();
//		
//		str.nextLine();
//		System.out.print("�̸� �Է� : ");
//		String name = str.nextLine();
//		
//		System.out.println("���� : " + age +"��");
//		System.out.println("�̸� : " + name);
//		name = str.next();
//		System.out.println("" + name);

		Scanner sc = new Scanner(System.in);
		
		System.out.print("�ڹ� ���� �Է� : ");
		int jScore = sc.nextInt();
		
		System.out.print("C��� ���� �Է� : ");
		int cScore = sc.nextInt();
		
		System.out.print("�̸� �Է� : ");
		sc.nextLine();
		String name = sc.nextLine();
		
		System.out.println("=====================");
		System.out.println("[ " +name+ " ]���� ���� ");
		
		int sum = jScore + cScore;
		System.out.println("�հ� : " + sum +"��");
		
		double avg = sum/2.0;
		System.out.println("��� : " + avg + "��");
	}
}














