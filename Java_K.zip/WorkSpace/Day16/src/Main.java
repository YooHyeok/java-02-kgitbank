
public class Main {

	public static void main(String[] args) {
//		Child c = new Child();
//		Child2 c2 = new Child2();	
//		c.disp();
//		Student st = new Student();
//		Student st1 = new Student("�谭��", 28);
//		Student st2 = new Student("�谭��", 28, 19, 90);
//		
//		st2.setHakjum(89);
//		st.dispInfo();
//		st1.dispInfo();
//		st2.dispInfo();
//		
//		Worker wk = new Worker("�谭��", 29);
//		Worker wk1 = new Worker("�谭ĥ", 30, 178.5, 75.5);
//		wk.dispInfo();
//		wk1.dispInfo();
		
		Score[] st = new Score[4];
		
		st[0] = new Score("�嵿��", 100, 100, 100);
		st[1] = new Score("����", 98, 78, 100);
		st[2] = new Score("������", 28, 78, 30);
		st[3] = new Score("�Ѱ���", 100, 92, 82);
		
		Score.showTitle();
		for(int i=0; i<st.length; i++) {
			st[i].showData();
		}
		Score.showTotal();
	}
}
//�̸�	�˰�����	�ΰ�����	����	����	���
//�嵿��	100		100		100	300	100.0
//����	98		78		100 276	92.0
//������	28		78		30	136	45.3
//�Ѱ���	100		92		82	274	91.3
//=======================================
//�Ѱ�	326		348		312	xxx	xxxx	

class Score{
	private String name;
	private int alg, ai, math, total;
	private double avg;
	
	static int tAlg, tAi, tMath, tTotal, count;
	static double tAvg;
	
//	{count++;}
	
	public Score(String name, int alg, int ai, int math) {
		this.name = name;
		this.alg = alg;
		this.ai = ai;
		this.math = math;
		Score.count += 3;
		
		this.setTotal(getAlg(), getAi(), getMath());
		this.setAvg(getTotal());
		
		Score.settAlg(getAlg());
		Score.settAi(getAi());
		Score.settMath(getMath());
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAlg() {
		return alg;
	}

	public void setAlg(int alg) {
		this.alg = alg;
	}

	public int getAi() {
		return ai;
	}

	public void setAi(int ai) {
		this.ai = ai;
	}

	public int getMath() {
		return math;
	}

	public void setMath(int math) {
		this.math = math;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int alg, int ai, int math) {
		this.total = alg + ai + math;
	}

	public double getAvg() {
		return avg;
	}

	public void setAvg(int total) {
		this.avg = total/3.0;
	}

	public static int gettAlg() {
		return tAlg;
	}

	public static void settAlg(int tAlg) {
		Score.tAlg += tAlg;
	}

	public static int gettAi() {
		return tAi;
	}

	public static void settAi(int tAi) {
		Score.tAi += tAi;
	}

	public static int gettMath() {
		return tMath;
	}

	public static void settMath(int tMath) {
		Score.tMath += tMath;
	}

	public static int gettTotal() {
		return tTotal;
	}

	public static void settTotal() {
		Score.tTotal = Score.tAlg + Score.tAi + Score.tMath;
	}

	public static int getCount() {
		return count;
	}

	public static double gettAvg() {
		return tAvg;
	}

	public static void settAvg(double tAvg) {
		Score.tAvg = tAvg/getCount();
	}
	
	public static void showTitle() {		
		System.out.print("�̸�\t");
		System.out.print("�˰�����\t");
		System.out.print("�ΰ�����\t");
		System.out.print("����\t");
		System.out.print("����\t");
		System.out.println("���\t");
	}
	
	public void showData() {
		System.out.print(getName()+"\t");
		System.out.print(getAlg()+"\t");
		System.out.print(getAi()+"\t");
		System.out.print(getMath()+"\t");
		System.out.print(getTotal()+"\t");
		System.out.println(getAvg()+"\t");
	}
	
	public static void showTotal() {
		Score.settTotal();
		Score.settAvg(gettTotal());
		
		System.out.print("�� �� : \t");
		System.out.print(gettAlg()+"\t");
		System.out.print(gettAi()+"\t");
		System.out.print(gettMath()+"\t");
		System.out.print(gettTotal()+"\t");
		System.out.print(gettAvg()+"\t");		
	}
	
	
}

//��� : �̸��� ����
//�л� : �̸�, ����, �й�, �׸��� ����
//ȸ��� : �̸�, ����, Ű, �����Ը� ���� Ŭ���� ����

class Person{
	private String name;
	private int age;
	
	Person(){
		System.out.println("Person");
	}
	Person(String name, int age){
		this.name =  name;
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	public void dispInfo() {
		System.out.println("�̸� : "+this.name);
		System.out.println("���� : "+this.age);
	}
}

class Student extends Person{
	private int hakbun;
	private int hakjum;
	
	Student(){
		super();
		System.out.println("Student");
	}
	Student(String name, int age){
		super.setName(name);
		super.setAge(age);		
	}
	Student(String name, int age, int hakbun, int hakjum){
		super.setName(name);
		super.setAge(age);		
		this.hakbun = hakbun;
		this.hakjum = hakjum;		
	}
	public int getHakbun() {
		return hakbun;
	}
	public void setHakbun(int hakbun) {
		this.hakbun = hakbun;
	}
	public int getHakjum() {
		return hakjum;
	}
	public void setHakjum(int hakjum) {
		this.hakjum = hakjum;
	}
	
	public void dispInfo() {
		super.dispInfo();
		System.out.println("�й� : "+this.hakbun);
		System.out.println("���� : "+this.hakjum);
	}	
}

class Worker extends Person{
	private double height;
	private double weight;
	
	Worker(){}
	Worker(String name, int age){
		super.setName(name);
		super.setAge(age);		
	}
	Worker(String name, int age, double height, double weight){
		super.setName(name);
		super.setAge(age);
		this.height = height;
		this.weight = weight;		
	}
	public double getHeight() {
		return height;
	}
	public void setHeight(double height) {
		this.height = height;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	
	public void dispInfo() {
		super.dispInfo();
		System.out.println("Ű : "+ this.height);
		System.out.println("������ : "+ this.weight);
	}
}

class Parent{
	int x = 10;
	void disp() {
		System.out.println("Parent");
	}
}

class Child extends Parent{
	int x = 20;
	void disp() {
		super.disp();
		System.out.println("Child");
//		int x = 30;
//		System.out.println("Child x="+x);
//		System.out.println("Child this.x="+this.x);
//		System.out.println("Child super.x="+super.x);
	}
}

//class Child2 extends Parent{
//	void disp() {
//		age = 20;
//		System.out.println("Child2 Age="+age);
//	}
//}



















