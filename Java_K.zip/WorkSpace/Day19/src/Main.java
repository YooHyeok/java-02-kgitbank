import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
//		ArrayListEx ale = new ArrayListEx();
//		ale.method();
		
		MapEx me = new MapEx();
		me.method();
	}
}

class ArrayListEx{
	void method() {
	
		ArrayList<Integer> list = new ArrayList<Integer>(3);
		list.add(new Integer(5));
		list.add(new Integer(4));
		list.add(new Integer(2));
		list.add(new Integer(0));
		list.add(new Integer(1));
		list.add(new Integer(3));
		
		ArrayList list1 = new ArrayList(list.subList(1, 4));
		
		list1.add("B");
		list1.add("C");
		list1.add(3, "A");
		System.out.println("list : "+ list);
		System.out.println("list1 : "+ list1);
		
		list1.set(3, "A+");
		System.out.println("list1 : "+ list1);
		
		list1.remove(2);
		System.out.println("list1 : "+ list1);
		
		Iterator it = list.iterator();
		
		Integer iTemp = new Integer(0);
		iTemp = list.get(0);
		System.out.println("iTemp : "+ iTemp);
		
		System.out.println("it.next() : " + it.next());
		System.out.println("it.next() : " + it.next());
		System.out.println("it.next() : " + it.next());
		System.out.println("it.next() : " + it.next());
		System.out.println("it.next() : " + it.next());
		System.out.println("it.next() : " + it.next());
		System.out.println("it.next() : " + it.next());
	}

}

class MapEx{
	void method() {
		HashMap map = new HashMap();
		map.put("kim kang sa", "1234");
		map.put("kks junior", "5678");
		map.put("kks junior", "6789");
		
		Scanner sc = new Scanner(System.in);
		
		while(true) {
			System.out.println("id�� password�� �Է� �� �ּ���.");
			System.out.print("id : ");
			String id = sc.nextLine().trim();
			System.out.print("password : ");
			String password = sc.nextLine().trim();
			
			if(!map.containsKey(id)) {
				System.out.println("id�� ���� ���� �ʽ��ϴ�.");
				continue;
			}else {
				if(!map.get(id).equals(password)) {
					System.out.println("��й�ȣ�� ��ġ���� �ʽ��ϴ�");
				}else {
					System.out.println("ȯ���մϴ�");
					break;
				}
			}
			
		}
	}
}
















