import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws InterruptedException {
//		Test t = new Test();
//		t.num = 10;
//		int sum = t.add(10,  20);
//		int [] result = new int[3];
//		
//		t.addArray(1, 2, result);
//		System.out.println("t.num="+t.num);
//		System.out.println("sum="+sum);
//		for(int i=0; i<result.length; i++) {
//			System.out.println(result[i]);			
//		}
//		dispMessage();
		
//		MethodEx me = new MethodEx();
//		MethodEx me1 = new MethodEx();
//		int a=3, b=4;
//		
//		System.out.println("me.add(a, b)="+me.add(a, b));
//		System.out.println("me.subtract(a, b)="+me.subtract(a, b));
//		System.out.println("me.multiply(a, b)="+me.multiply(a, b));
//		System.out.println("me.divide(a, b)="+me.divide(a, b));
//		System.out.println("MethodEx.sAdd(a, b)="+MethodEx.sAdd(a, b));
//		System.out.println("me.sAdd(a, b)="+me.sAdd(a, b));
//		System.out.println("me1.sAdd(a, b)="+me1.sAdd(a, b));
//		PersonalInfo info = new PersonalInfo();
//		info.age = 38;
//		info.name = "�嵿��";
//		info.setAge(38);
//		info.setName("�嵿��");
//		System.out.println("���� : "+info.getAge());
//		System.out.println("�̸� : "+info.getName());
//		HumanSam sam = new HumanSam();
//		HumanSam samJ = new HumanSam();
//		
//		sam.setName("�谭��");
//		samJ.setName("�谭��J");
//		sam.setInfo();
//		sam.getInfo();
		Timer t = new Timer();
		Scanner sc = new Scanner(System.in);
		
		System.out.print("�ð� �Է� : ");
		int hour = sc.nextInt();
		
		System.out.print("�� �Է� : ");
		int minute = sc.nextInt();
		minute = hour*60 + minute;
		
		System.out.print("�� �Է� : ");
		int second = sc.nextInt();
		
		second = minute*60 + second;
		
		for(int i=hour; i>=0; i--) {
			t.setHour(i);
			for(int j=minute%60; j>=0; j--) {
				t.setMinute(j);
				for(int k=second%60; k>=0; k--) {
					t.setSecond(k);
					t.dispTime();
					Thread.sleep(500);
					second--;
				}
				minute--;
			}
		}
		System.out.println("����ؿ� ������!!!");
	}
	
	static void dispMessage() {
		System.out.println("dispMessage()");
	}
}
//Timer ����
//����ڷ� ���� ��, ��, �� ������ �Է� �޾� �ð��� ���� �Ŀ� 
//"����մϴ�. ������!!!"���
class Timer{
	private int hour;
	private int minute;
	private int second;
	
	public int getHour() {
		return hour;
	}
	public void setHour(int hour) {
		if(hour<0) {
			hour = 23;
		}else if(hour>23) {
			hour = 0;
		}
		this.hour = hour;
	}
	public int getMinute() {
		return minute;
	}
	public void setMinute(int minute) {
		if(minute<0) {
			minute = 59;
		}else if(minute>59) {
			minute = 0;
		}
		this.minute = minute;
	}
	public int getSecond() {
		return second;
	}
	public void setSecond(int second) {
		if(second<0) {
			second = 59;
		}else if(second>59) {
			second = 0;
		}
		this.second = second;
	}
	
	public void dispTime() {
		System.out.print(getHour() + "�ð�");
		System.out.print(getMinute() + "��");
		System.out.println(getSecond() + "��");
	}
	
}

//�̸�, ����, ������, �÷�, ������, �ּ�, ��ȭ��ȣ, ����, ���, ����
class HumanSam{
	private String name;
	private int age;
	private char blood;
	private double sight, weight;
	private String address, phoneNumber;
	private float hakjum;
	private String hobby, character;
	
	public void setInfo() {
		setName("����");
		setAge(25);
		setBlood('B');
		setSight(1.2);
		setWeight(75.5);
		setAddress("���� ���� ������� ���ϻ� �ڳ�");
		setPhoneNumber("010 44x7 1xx8");
		setHakjum(3.5f);
		setHobby("ö�λ��� ����忡�� �� ���� ������");
		setCharacter("��Ʋ, ����Ʈ, ������, ����Ʈ�Ѱ��� ���ϰ� �ٶ�");

	}
	public void getInfo() {
		System.out.println(getName());
		System.out.println(getAge());
		System.out.println(getBlood());
		System.out.println(getSight());
		System.out.println(getWeight());
		System.out.println(getAddress());
		System.out.println(getPhoneNumber());
		System.out.println(getHakjum());
		System.out.println(getHobby());
		System.out.println(getCharacter());
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public char getBlood() {
		return blood;
	}
	public void setBlood(char blood) {
		this.blood = blood;
	}
	public double getSight() {
		return sight;
	}
	public void setSight(double sight) {
		this.sight = sight;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public float getHakjum() {
		return hakjum;
	}
	public void setHakjum(float hakjum) {
		this.hakjum = hakjum;
	}
	public String getHobby() {
		return hobby;
	}
	public void setHobby(String hobby) {
		this.hobby = hobby;
	}
	public String getCharacter() {
		return character;
	}
	public void setCharacter(String character) {
		this.character = character;
	}	
}

class PersonalInfo{
	private int age;
	private String name;	
	
	void setAge(int age1) {
		age = age1;
	}
	int getAge() {
		return age;
	}
	
	void setName(String name1) {
		name = name1;
	}
	String getName() {
		return name;
	}
	
	
}
//MethodEx ����� ������ Ÿ���� �����ϰ�
//��Ģ ������ �����ϴ� �޼��� �����ϱ�
class MethodEx{
	static long sAdd(long a, long b) {
		long result = a+b;
		return result;		
	}
	
	long add(long a, long b) {
		long result = a+b;
		return result;
	}
	long subtract(long a, long b) {
		return a-b;
	}
	long multiply(long a, long b) {
		return a*b;
	}
	double divide(double a, double b) {
		return a/b;
	}
}



class Test{
	int num;
	
	void addArray(int a, int b, int [] result) {
		result[0] = a;
		result[1] = b;
		result[2] =  add(result[0], result[1]);
	}
	
	int add(int a, int b) {
		int result;
		
		result = a+b;
		
		return result;
	}
}