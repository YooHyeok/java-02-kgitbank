
public class Main {

	public static void main(String[] args) {
//		FireCar fc = new FireCar();
//		Ambulance ac = new Ambulance();
//		Car c1 = new Car();
		
//		ac = (Ambulance)fc;
//		fc = (FireCar)ac;
		
//		c = fc;
//		System.out.println("c.door="+c.door);
//		c.message();
//		
//		fc.drive(c);
//		c = ac;
//		ac.drive(c);
//		ac = (Ambulance)c1;
		
//		Buyer b = new Buyer();
//		Tv t = new Tv(100);
//		Computer c = new Computer(300);
//		Audio a = new Audio(200);
//		
//		b.buy(t);
//		b.buy(c);
//		b.buy(a);
//		
//		b.disp();	
		
		//0113_HW
		//���� ��ǰ ����Ʈ�� �����
		
		ExceptionEx eex = new ExceptionEx();
//		eex.exMethod();
//		eex.orderedException();
//		eex.userException();
		eex.methodEx();
		System.out.println("���α׷� ����");
	}

}
//���� ó�� ��ƾ ���� �Ұ�
class ExceptionEx{
	void methodEx() {	
		try{
			methodEx1();
		}catch(Exception e) {
			System.out.print(e.getMessage());
			System.out.println(" : methodEx()���� ���� ó��");
		}
	}
	void methodEx1() throws Exception {	methodEx2();	}
	void methodEx2() throws Exception {
		try {
			Exception e = new Exception("methodEx2()���� ���� �߻�");
			throw e;
		}catch(Exception e) {
			System.out.print(e.getMessage());
			System.out.println(" : methodEx2()���� ���� ó��");
			throw e;			
		}
		
	}
	void userException() {
		try {
			Exception e = new Exception("����� ���ܹ߻�");
			throw e;	
		}catch(Exception e) {
			System.out.println(e.getMessage());
			System.out.println("userException()���� ���� ó��");
		}
	}
	void orderedException() {
		System.out.println(1);
		try {
			System.out.println(2);
			System.out.println(0/0);
			System.out.println(3);
		}catch(Exception e) {
			System.out.println(4);
		}
		System.out.println(5);
	}
	void exMethod() {
		int num = 100;
		int result = 0;
		int i=0; 
		
		while(i<10) {
			try {
				result = num/(int)(Math.random()*10);		
				System.out.println(result);
				return;
			}catch(ArithmeticException ae) {
				ae.printStackTrace();
				System.out.println(ae.getMessage());
			}finally {
				System.out.println("finally ����");
			}
			i++;
		}
	}
	void method() {		
//		try {
//			
//		}catch(Exception e) {
//			
//		}
//		try {
//			try {}
//			catch(Exception e) {}
//		}catch(Exception e) {
//			try {} catch(ExceptionEx e) {}
//			
//		}
	}
}

class Product{
	private int price;
	private int bonusPoint;
	
	Product(int price){
		this.price = price;
		this.bonusPoint = (int)(price/10.0);
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getBonusPoint() {
		return bonusPoint;
	}

	public void setBonusPoint(int bonusPoint) {
		this.bonusPoint = bonusPoint;
	}
	
	
}

class Tv extends Product{
	Tv(int price){
		super(price);
	}
	
	public String toString() {
		return "Tv";
	}
}

class Computer extends Product{
	Computer(int price){
		super(price);
	}
	
	public String toString() {
		return "Computer";
	}
}

class Audio extends Product{
	Audio(int price){
		super(price);
	}
	
	public String toString() {
		return "Audio";
	}
}

class Buyer{
	private int money = 1000;
	private int bonusPoint = 0;
	Product [] item = new Product[10];
	int index=0;
	
	Buyer(){}

	public int getMoney() {
		return money;
	}

	public void setMoney(int money) {
		this.money = money;
	}

	public int getBonusPoint() {
		return bonusPoint;
	}

	void buy(Product p) {
		if(this.money < p.getPrice()) {
			System.out.println("�ܾ��� �����մϴ�.");
			return;
		}
		this.money -= p.getPrice();
		this.bonusPoint += p.getBonusPoint();
		System.out.println(p+"�� �����ϼ̽��ϴ�.");
		item[index++] = p;
	}
	
	void disp() {
		int sum=0;
		String itemList="";
		
		for(int i=0; i<item.length; i++) {
			if(item[i]==null) {
				break;
			}
			sum += item[i].getPrice();
			itemList += item[i] + ", ";
		}
		System.out.println("�� ���� �ݾ��� "+sum+"���� �̰�,");
		System.out.println("�����Ͻ� ��ǰ�� "+itemList+"�Դϴ�.");
		System.out.println("���� �ܾ��� "+getMoney()+"���� �̰�, ");
		System.out.println("���ʽ� ������ "+getBonusPoint()+"�� �Դϴ�.");
	}
	
}

class Car{
	String color;
	int door=2;
	
	void message() {
		System.out.println("Car");
	}
	
	void drive(Car c) {
		if(c instanceof FireCar) {
			FireCar fc = (FireCar)c;
			fc.water();
		}else if(c instanceof Ambulance) {
			Ambulance ac = (Ambulance)c;
			ac.hospital();
		}
		System.out.println("���");
	}
	void park() {
		System.out.println("����");
	}
}

class FireCar extends Car{
	int door = 4;
	void message() {
		System.out.println("FireCar");
	}
	void water() {
		System.out.println("[�ҹ���]");
	}
}

class Ambulance extends Car{
	int door = 5;
	void message() {
		System.out.println("Ambulance");
	}
	void hospital() {
		System.out.println("[�ں深��]");
	}
}




















