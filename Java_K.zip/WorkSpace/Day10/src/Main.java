import java.util.Arrays;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
//		int [] arr = {1,2,3,4,5};
//		int [] arr = new int[] {10,20,30,40,50};
//		int [] arr = new int[5];
//		
//		for(int i=0; i<arr.length; i++) {
//			System.out.println("arr["+i+"]="+arr[i]);
//		}
		
		//�迭 �ʱ�ȭ�� �̿��� ���հ� ��� ���ϱ�
//		int [] score = {100,88,97,45,13};
//		
//		int sum=0;
//		for(int i=0; i<score.length; i++) {
//			sum += score[i];
//		}
//		
//		float avg = (float)sum/score.length;
//		
//		System.out.println("���� : " + sum);
//		System.out.println("��� : " + avg);
		
		//�� 10���� �迭�� �����ϰ� �ִ밪�� �ּҰ��� ���ϱ�
//		int [] rDigit = new int[] {234,5,6,76,3,234,56734,2,34,3456};
//		int max = rDigit[0];
//		int min = rDigit[0];
//		
//		for(int i=1; i<rDigit.length; i++) {
//			if(rDigit[i]>max) {
//				max = rDigit[i];
//			}
//			if(rDigit[i]<min) {
//				min = rDigit[i];
//			}
//		}
//		System.out.println("�ִ밪 : " + max);
//		System.out.println("�ּҰ� : " + min);
		
//		String [] name = new String[3];
//		name[0] = new String("�谭��");
//		name[1] = "�̰���";
//		name[2] = new String("�ڰ���");
		
//		String [] name = {new String("�谭��"), new String("�̰���"), new String("�ڰ���")};
//		String [] name = {"�谭��", "�ڰ���", "�̰���"};
//		for(int i=0; i<name.length; i++) {
//			System.out.println("�̸� : " + name[i]);
//		}
		
//		int [] rDigit = new int[] {234,5,6,76,3,234,56734,2,34,3456};
//		int [] bDigit = new int[rDigit.length];
		
//		for(int i=0; i<bDigit.length; i++) {
//			bDigit[i] = rDigit[i];
//		}
//		System.arraycopy(rDigit, 0, bDigit, 0, rDigit.length);
//		
//		for(int i=0; i<rDigit.length; i++) {
//			System.out.print(rDigit[i]+" ");			
//		}
//		System.out.println();
//		for(int i=0; i<bDigit.length; i++) {
//			System.out.print(bDigit[i]+" ");			
//		}
		
//		int [][] arr = new int[3][];
//		arr[0] = new int[4];
//		arr[1] = new int[3];
//		arr[2] = new int[8];
//		int count=1;
//		
//		for(int i=0; i<arr.length; i++) {
//			for(int j=0; j<arr[i].length; j++) {
//				arr[i][j]=count++;
//			}
//		}
//		for(int i=0; i<arr.length; i++) {
//			for(int j=0; j<arr[i].length; j++) {
//				System.out.println("arr["+i+"]["+j+"]="+arr[i][j]);
//			}
//			System.out.println();
//		}
	
		//�迭�� ũ�⸦ �Է� �޾Ƽ� 2���� �迭 �����ϰ� 1���� ���� �Է�
		Scanner sc = new Scanner(System.in);
		int count=1;
		
		System.out.print("1���迭 ũ�� : ");
		int row = sc.nextInt();
		
		System.out.print("2���迭 ũ�� : ");
		int col = sc.nextInt();
		
		System.out.println("�迭["+row+"]["+col+"]�� ��");
		
		int [][] arr = new int[row][col];
		
		for(int i=0; i<arr.length; i++) {
			for(int j=0; j<arr[i].length; j++) {
				arr[i][j] = count++;
			}
		}
		for(int i=0; i<arr.length; i++) {
			for(int j=0; j<arr[i].length; j++) {
				System.out.println("arr["+i+"]["+j+"]="+arr[i][j]);
			}
			System.out.println();
		}		
	}
}





















