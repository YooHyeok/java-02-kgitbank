import java.util.Arrays;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
//		DataEx de = new DataEx();
//		de.x = 10;
//		int [] arr = {1,2,3,4,5};
//		
//		System.out.println("main().de.x : "+ de.x);
//		change(de);
//		System.out.println("After change()");
//		System.out.println("main().de.x : "+ de.x);
//		
//		System.out.println("main().arr : "+ Arrays.toString(arr));
//		changeArray(arr);
//		System.out.println("After changeArray()");
//		System.out.println("main().arr : "+ Arrays.toString(arr));
		
//		System.out.println(de.add(3, 4));
//		System.out.println(de.add(3L, 4));
//		System.out.println(de.add(3L, 4L));
//		System.out.println(de.add(3, 4L));
//		System.out.println(de.add(arr));
		
		Calc clc = new Calc();
		Scanner sc = new Scanner(System.in);
		
//		while(true) {
//			System.out.print("�Է� 1 : ");
//			int fNum = sc.nextInt();
//			System.out.print("�Է� 2 : ");		
//			int sNum = sc.nextInt();
//			
//			sc.nextLine();
//			System.out.print("������ : ");		
//			String oper = sc.nextLine();
//		
//			switch(oper) {
//			case "+" :
//				System.out.println(clc.add(fNum, sNum));
//				break;
//			case "-" :
//				System.out.println(clc.subtract(fNum, sNum));
//				break;
//			case "*" :
//				System.out.println(clc.multiply(fNum, sNum));
//				break;
//			case "/" :
//				System.out.println(clc.divide(fNum, sNum));
//				break;
//			default : 
//				System.out.println("�� ���� �Է� ");
//			}
//		}
		
		System.out.println(clc.add(3.1,  3));
		System.out.println(clc.subtract(3.1,  3));
		System.out.println(clc.multiply(3.1,  3.1));
		System.out.println(clc.divide(3.1,  3));
		
	}
	
//	static void change(int x) {
	static void change(DataEx de) {
		de.x = 1000;
		System.out.println("change().x : "+de.x);
	}
	
	static void changeArray(int [] arr) {
		arr[0] = 10;
		arr[1] = 20;
		System.out.println("changeArray() : "+Arrays.toString(arr));
	}
}

//�޼ҵ� �����ε��� ������ 4Ģ�����(����) ������ ������
class Calc{
	long add(long a, long b){
		return a+b;
	}
	double add(double a, double b){
		return a+b;
	}
	
	long subtract(long a, long b){
		return a-b;
	}
	double subtract(double a, double b){
		return a-b;
	}
	
	long multiply(long a, long b){
		return a*b;
	}
	double multiply(double a, double b){
		return a*b;
	}
	
	long divide(long a, long b){
		return a/b;
	}
	double divide(double a, double b){
		return a/b;
	}
}


class DataEx{
	int x;
	
	int add(int a, int b) {
		System.out.println("int add(int a, int b)");
		return a+b;
	}
	
	long add(long x, int y) {
		System.out.println("long add(long x, int y)");
		return x+y;
	}
	
	long add(long x,long y) {
		System.out.println("long add(long x,long y)");
		return x+y;
	}
	
	long add(int [] arr) {
		int result=0;
		System.out.println("long add(int [] arr)");
		
		for(int i=0; i<arr.length; i++) {
			result += arr[i];
		}
		return result;
	}
}

















